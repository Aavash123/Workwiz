<section id="content">
	<section class="section-padding">
		<div class="container">
			<div class="row showcase-section">
				<div class="col-md-6">
					<img src="plugins\home-plugins\img\dev1.jpg" alt=" " style="width:30em">
				</div>
				<div class="col-md-6">
					<div class="about-text">
						<h3>Know more</h3>
						<p>we value integrity, transparency, and equal opportunities. We are dedicated to fostering a fair and inclusive environment where every individual has a chance to showcase their skills and potential. We believe that the right job can transform lives, and we are proud to be part of that journey..</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	 <div class="container">
					
					<div class="about">
				
						
						<div class="row">
							<div class="col-md-4">
								<!-- Heading and para -->
								<div class="block-heading-two">
									<h3><span>Why Choose Us?</span></h3>
								</div>
								<p>What sets us apart is our commitment to providing a seamless user experience. We have designed our platform to be intuitive, allowing job seekers to easily search and apply for relevant positions,<br/> while employers can efficiently manage their recruitment process. We also offer additional features such as resume building tools, career advice articles, and personalized job recommendations to enhance the overall experience.</p>
							</div>
							<div class="col-md-4">
								<div class="block-heading-two">
									
								
							</div>
							
							<div class="col-md-4">
								<div class="block-heading-two">
									<h3><span>Our Expertise</span></h3>
								</div>								
								<h6>Web Development</h6>
								<div class="progress pb-sm">
								  <!-- White color (progress-bar-white) -->
								  <div class="progress-bar progress-bar-red" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
									 <span class="sr-only">40% Complete (success)</span>
								  </div>
								</div>
								<h6>Designing</h6>
								<div class="progress pb-sm">
								  <div class="progress-bar progress-bar-green" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%">
									 <span class="sr-only">40% Complete (success)</span>
								  </div>
								</div>
								<h6>User Experience</h6>
								<div class="progress pb-sm">
								  <div class="progress-bar progress-bar-lblue" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
									 <span class="sr-only">40% Complete (success)</span>
								  </div>
								</div>
								<h6>Development</h6>
								<div class="progress pb-sm">
								  <div class="progress-bar progress-bar-yellow" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="width: 30%">
									 <span class="sr-only">40% Complete (success)</span>
								  </div>
								</div>
							</div>
							
						</div>
						
						 						
						 
						<br>
						<!-- Our Team starts -->
				
						<!-- Heading -->
						<div class="block-heading-six">
							<h4 class="bg-color">Our Team</h4>
						</div>
						<!-- <br> -->
						
						<!-- Our team starts -->
						
						<div class="team-six">
							<div class="row">
								<div class="col-md-3 col-sm-6">
									<!-- Team Member -->
									<div class="team-member">
										<!-- Image -->
										<img class="img-responsive" src="img/team1.jpg" alt="">
										<!-- Name -->
										<h4>Bijina Maharjan</h4>
										<span class="deg">Creative</span> 
									</div>
								</div>
								<div class="col-md-3 col-sm-6">
									<!-- Team Member -->
									<div class="team-member">
										<!-- Image -->
										<img class="img-responsive" src="img/team2.jpg" alt="">
										<!-- Name -->
										<h4>Kabita</h4>
										<span class="deg">Programmer</span> 
									</div>
								</div>
								<div class="col-md-3 col-sm-6">
									<!-- Team Member -->
									<div class="team-member">
										<!-- Image -->
										<img class="img-responsive" src="img/team3.jpg" alt="">
										<!-- Name -->
										<h4>Ram</h4>
										<span class="deg">CEO</span> 
									</div>
								</div>
								<div class="col-md-3 col-sm-6">
									<!-- Team Member -->
									<div class="team-member">
										<!-- Image -->
										<img class="img-responsive" src="img/team4.jpg" alt="">
										<!-- Name -->
										<h4>Hari</h4>
										<span class="deg">Manager</span> 
									</div>
								</div>
							</div>
						</div>
						
						<!-- Our team ends -->
					  
						
					</div>
									
				</div>
	</section>
